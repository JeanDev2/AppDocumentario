<?php
include('c.php');

// CAMPOS DEL FORMULARIO
$suministroFach = $_POST['suministroFach'];
$nombreFach = $_POST['nombreFach'];
$direccionFach = $_POST['direccionFach'];
$catastroFach = $_POST['catastroFach'];
$categoriaFach = $_POST['categoriaFach'];
$fechaFach = $_POST['fechaFach'];
//CAMPO DE LAS IMAGENES
$n_archivo = $_FILES['imagen1']['name'];
$archivo = $_FILES['imagen1']['tmp_name'];
$n_archivo2 = $_FILES['imagen2']['name'];
$archivo2 = $_FILES['imagen2']['tmp_name'];
$n_archivo3 = $_FILES['imagen3']['name'];
$archivo3 = $_FILES['imagen3']['tmp_name'];
$n_archivo4 = $_FILES['imagen4']['name'];
$archivo4 = $_FILES['imagen4']['tmp_name'];

//RUTA DE LAS IMAGENES
$ruta = "../image/" . $n_archivo;
$ruta2 = "../image/" . $n_archivo2;
$ruta3 = "../image/" . $n_archivo3;
$ruta4 = "../image/" . $n_archivo4;
//DIRECCION PARA LA BASE DE DATOS DE LAS IMAGENES
$base_datos = "image/" . $n_archivo;
$base_datos2 = "image/" . $n_archivo2;
$base_datos3 = "image/" . $n_archivo3;
$base_datos4= "image/" . $n_archivo4;
//CREACION LAS IMAGENES EN LA CARPETA IMAGE
move_uploaded_file($archivo,$ruta);
move_uploaded_file($archivo2,$ruta2);
move_uploaded_file($archivo3,$ruta3);
move_uploaded_file($archivo4,$ruta4);

$insertar = mysqli_query($conexion, "INSERT INTO usuarios (suministro, nombre, direccion, catastro, categoria, fecha, imagen1, imagen2, imagen3, imagen4) 
VALUES ('$suministroFach','$nombreFach','$direccionFach','$catastroFach','$categoriaFach','$fechaFach','$base_datos','$base_datos2','$base_datos3','$base_datos4')");

if($insertar){
	echo '
	
	<script>
	alert("Los datos se guardaron exitosamente");
	</script>
	
	';

header("location:../pages/vista-suministro.php");

}else{

	echo '
	
	<script>
	alert("Los datos no se guardaron");
	</script>
	
	';
	header("location:../pages/vista-suministro.php");
}

?>