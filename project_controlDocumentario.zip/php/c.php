<?php
//  $conexion = mysqli_connect('andshopperu.com','andshopp_trivecaeps','trivecaweb2023$5','andshopp_controldocumentario');
	 $conexion = mysqli_connect('127.0.0.1:3308','root','','andshopp_controldocumentario');
?>


